import os, json, io, sqlite3
from pathlib import Path
from datetime import datetime
import streamlit as st

BASE=Path(__file__).parent
DB=BASE/'smart_notes.db'
def conn():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def now(): return datetime.now().strftime('%d %b %Y, %H:%M')
with conn() as c:
    c.executescript('''CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY,title TEXT,subject TEXT,method TEXT,content TEXT,source TEXT,fav INTEGER DEFAULT 0,created TEXT);
    CREATE TABLE IF NOT EXISTS recordings(id INTEGER PRIMARY KEY,title TEXT,subject TEXT,file TEXT,transcript TEXT,created TEXT);
    CREATE TABLE IF NOT EXISTS tests(id INTEGER PRIMARY KEY,note_id INTEGER,title TEXT,subject TEXT,score INTEGER,total INTEGER,pct REAL,details TEXT,created TEXT);''')

def paras(t): return [x.strip() for x in t.splitlines() if x.strip()]
def sents(t):
    import re
    return [x.strip() for x in re.split(r'(?<=[.!?])\s+',re.sub(r'\s+',' ',t).strip()) if len(x.strip())>20]
def keywords(t):
    import re
    stop=set('the a an and or but if then of in on at to for from by with is are was were be this that it as into can could will may we you they'.split())
    f={}
    for w in re.findall(r'[A-Za-z][A-Za-z0-9-]{3,}',t.lower()):
        if w not in stop:f[w]=f.get(w,0)+1
    return [w for w,n in sorted(f.items(),key=lambda x:-x[1])[:12]]
def definitions(t):
    import re
    out=[]
    patterns=[r'([A-Z][\w ()/-]{1,50}?)\s+(?:is defined as|is|are|refers to|means)\s+([^.!?\n]{8,180})',r'([A-Z][\w ()/-]{1,50})\s*:\s*([^.!?\n]{8,180})']
    for p in patterns:
        for a,b in re.findall(p,t):
            if len(a.split())<9 and (a,b) not in out:out.append((a.strip(),b.strip()))
    return out[:8]
def generate(title,subject,source,method):
    import re
    ps=paras(source); ss=sents(source) or ps
    heads=[x.strip(' #:-') for x in ps if len(x.split())<=9 and not x.endswith(('.','?','!'))]
    sig=('important','therefore','because','however','consists','defined','example','such as','process','function','advantages','formula','result')
    key=sorted(ss,key=lambda x:sum(z in x.lower() for z in sig)+min(len(x),240)/240,reverse=True)[:8]
    ds=definitions(source); kw=keywords(source); summary=' '.join(ss[:3])
    qs=[f'Explain {h}.' for h in heads[:4]]+[f'Define {a}.' for a,b in ds[:4]]+[f'Why is {k} important?' for k in kw[:4]]
    if not qs:qs=['What are the main ideas in this lecture?']
    out=[f'# {title}',f'**Subject:** {subject}',f'**Method:** {method}','']
    if method=='Cornell Method':out+=['## Cue questions']+[f'- {q}' for q in qs]+['','## Lecture notes']+[f'- {x}' for x in ss[:12]]+['','## Summary',summary]
    elif method=='Outline Method':
        out+=['## Main headings']
        for h in heads[:7]:out += [f'### {h}']+[f'- {x}' for x in ([x for x in ss if h.lower().split()[0] in x.lower()][:3] or ss[:2])]
        if not heads:out+=['### Core ideas']+[f'- {x}' for x in ss[:10]]
        out+=['','## Important points']+[f'- {x}' for x in key]
    elif method=='Mind Mapping':
        out += [f'## Central topic: {title}','```text',title]
        for i,h in enumerate(heads[:7] or kw[:7]):out += [f'├── {h}']+[f'│   └── {x}' for x in ([x for x in ss if h.lower().split()[0] in x.lower()][:2] or ss[i:i+1])]
        out+=['```']
    else:
        out+=['## Concept chart','| Topic | Explanation |','|---|---|']
        for i,h in enumerate(heads[:7] or kw[:7]):
            rel=[x for x in ss if h.lower().split()[0] in x.lower()]
            out += [f"| {h} | {(rel or ss[i:i+1] or ['See lecture'])[0].replace('|','/')} |"]
        out+=['','## Important points']+[f'- {x}' for x in key]
    out+=['','## Key definitions']+([f'- **{a}:** {b}' for a,b in ds] or ['- No explicit definition pattern detected.'])
    out+=['','## Important keywords',', '.join(kw),'','## Short summary',summary,'','## Revision questions']+[f'{i+1}. {q}' for i,q in enumerate(qs)]
    return '\n'.join(out)
def makequiz(text,count,typ):
    import re
    ss=sents(text); kw=keywords(text); ds=definitions(text); q=[]
    for a,b in ds:q.append(dict(type='Short Answer',question=f'Define {a}.',answer=b,explanation=f'The notes define {a} as {b}',options=[]))
    for x in ss:
        words=re.findall(r'\b[A-Za-z][A-Za-z0-9-]{3,}\b',x); candidates=[w for w in words if w.lower() in kw]
        if candidates:
            ans=max(candidates,key=len); blank=re.sub(r'\b'+re.escape(ans)+r'\b','________',x,count=1,flags=re.I)
            q.append(dict(type='Fill in the Blanks',question=blank,answer=ans,explanation=x,options=[]))
        q.append(dict(type='True or False',question='True or False: '+x,answer='True',explanation='This statement is directly supported by the saved notes.',options=['True','False']))
        q.append(dict(type='Important Exam Question',question='Discuss the following lecture point: '+x,answer=x,explanation='Use this point from the saved notes as the basis of a complete exam answer.',options=[]))
    if typ in ('MCQ','Mixed'):
        for item in q:
            if item['type']=='Fill in the Blanks' and len(kw)>2:
                item['options']=list(dict.fromkeys([item['answer']]+[z for z in kw if z.lower()!=item['answer'].lower()][:3])); item['type']='MCQ'
    if typ not in ('Mixed','All'):q=[x for x in q if x['type']==typ]
    seen=set(); q=[x for x in q if not (x['question'] in seen or seen.add(x['question']))]
    return q[:max(1,min(int(count),30))]
def grade(ans,expected,kind):
    if kind in ('MCQ','Fill in the Blanks','True or False'):return ans.strip().lower()==expected.strip().lower()
    a=set(keywords(ans)); e=set(keywords(expected)); return bool(e) and len(a&e)/len(e)>=.35
def notes(q=''):
    with conn() as c:return [dict(x) for x in c.execute('SELECT * FROM notes WHERE title LIKE ? OR subject LIKE ? ORDER BY id DESC',(f'%{q}%',f'%{q}%'))]
def pdf_bytes(title,content):
    from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.pagesizes import A4
    b=io.BytesIO(); d=SimpleDocTemplate(b,pagesize=A4); styles=getSampleStyleSheet(); story=[Paragraph(title,styles['Title'])]
    for line in content.splitlines():
        if line.strip():story.extend([Paragraph(line.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('**',''),styles['BodyText']),Spacer(1,5)])
    d.build(story); return b.getvalue()

st.set_page_config(page_title='Smart Lecture Notes Maker',page_icon='📚',layout='wide')
st.markdown('''<style>.stApp{background:linear-gradient(135deg,#f8f5ff,#fff)}.block-container{max-width:1200px;padding-top:1.5rem}.hero{padding:1.5rem 2rem;border-radius:22px;color:white;background:linear-gradient(110deg,#4c1d95,#7c3aed,#a78bfa);margin-bottom:1rem}.hero h1{color:white}.hero p{color:#f0eaff}div.stButton>button[kind=primary]{background:#6d28d9;border-color:#6d28d9}</style>''',unsafe_allow_html=True)
st.markdown('<div class="hero"><h1>📚 Smart Lecture Notes Maker</h1><p>Turn lecture text and audio into organised notes, revision material and practice tests.</p></div>',unsafe_allow_html=True)
with conn() as c:
    counts=[c.execute('SELECT count(*) FROM notes').fetchone()[0],c.execute('SELECT count(*) FROM recordings').fetchone()[0],c.execute('SELECT count(*) FROM tests').fetchone()[0],c.execute('SELECT avg(pct) FROM tests').fetchone()[0] or 0]
cols=st.columns(4)
for col,label,val in zip(cols,['Saved notes','Recordings','Practice tests','Average score'],[counts[0],counts[1],counts[2],f'{counts[3]:.1f}%']):col.metric(label,val)
tabs=st.tabs(['🏠 Dashboard','✍️ Create notes','🎙️ Audio to notes','📝 My notes','🧠 Quiz & tests','📜 History'])
with tabs[0]:
    st.subheader('Welcome'); st.write('Paste lecture content or record/upload audio, create notes in four formats, then practise with a quiz.')
    st.markdown('**How it works**\n1. Add lecture text or audio.\n2. Generate Cornell, Outline, Mind Map or Chart notes.\n3. Edit, search, favourite and export.\n4. Create a quiz from any saved note.')
    for n in notes()[:5]:st.write(f"• **{n['title']}** — {n['subject']} ({n['created']})")
with tabs[1]:
    st.subheader('Create notes from lecture text')
    with st.form('create'):
        title=st.text_input('Lecture title'); subject=st.text_input('Subject'); method=st.selectbox('Notes format',['Cornell Method','Outline Method','Mind Mapping','Chart Method']); source=st.text_area('Paste lecture transcript / text',height=220); go=st.form_submit_button('Generate and save notes',type='primary')
    if go:
        if not title.strip() or not subject.strip() or len(source.strip())<60:st.error('Enter title, subject and at least 60 characters of content.')
        else:
            content=generate(title,subject,source,method)
            with conn() as c:nid=c.execute('INSERT INTO notes(title,subject,method,content,source,created) VALUES(?,?,?,?,?,?)',(title,subject,method,content,source,now())).lastrowid
            st.session_state['new_note']=nid; st.success('Notes generated and saved.')
    if st.session_state.get('new_note'):
        with conn() as c:n=c.execute('SELECT * FROM notes WHERE id=?',(st.session_state['new_note'],)).fetchone()
        if n:
            st.markdown(n['content']); st.download_button('Download TXT',n['content'],file_name='lecture-notes.txt'); st.download_button('Download PDF',pdf_bytes(n['title'],n['content']),file_name='lecture-notes.pdf',mime='application/pdf')
with tabs[2]:
    st.subheader('Audio recording and transcription'); st.info('Audio transcription requires an OpenAI API key in Streamlit Cloud → App settings → Secrets.')
    audio=st.audio_input('Record lecture with microphone') if hasattr(st,'audio_input') else None
    upload=st.file_uploader('Or upload audio',type=['wav','mp3','m4a','webm','mp4','mpeg']); audio=upload or audio
    rt=st.text_input('Recording title',value='Recorded lecture'); rs=st.text_input('Subject',value='General')
    if st.button('Transcribe audio',type='primary',disabled=audio is None):
        key=st.secrets.get('OPENAI_API_KEY',os.getenv('OPENAI_API_KEY',''))
        if not key:st.error('Add OPENAI_API_KEY under Streamlit Cloud → App settings → Secrets.')
        else:
            try:
                from openai import OpenAI
                result=OpenAI(api_key=key).audio.transcriptions.create(model=os.getenv('OPENAI_TRANSCRIBE_MODEL','gpt-4o-mini-transcribe'),file=(getattr(audio,'name','lecture_audio.wav'),audio.getvalue()))
                transcript=result.text
                with conn() as c:rid=c.execute('INSERT INTO recordings(title,subject,file,transcript,created) VALUES(?,?,?,?,?)',(rt,rs,'',transcript,now())).lastrowid
                st.session_state['transcript']=transcript; st.session_state['recording_id']=rid; st.success('Transcription saved.')
            except Exception as e:st.error(f'Transcription failed: {e}')
    if st.session_state.get('transcript'):
        tr=st.text_area('Review/edit transcript',st.session_state['transcript'],height=170); nt=st.text_input('Notes title',rt); ns=st.text_input('Notes subject',rs); nm=st.selectbox('Notes format',['Outline Method','Cornell Method','Mind Mapping','Chart Method'])
        if st.button('Generate notes from transcript'):
            if len(tr.strip())<60:st.error('Transcript must contain at least 60 characters.')
            else:
                body=generate(nt,ns,tr,nm)
                with conn() as c:c.execute('INSERT INTO notes(title,subject,method,content,source,created) VALUES(?,?,?,?,?,?)',(nt,ns,nm,body,tr,now()))
                st.success('Notes saved. Open My notes to view and export.')
with tabs[3]:
    st.subheader('My notes'); search=st.text_input('Search title or subject'); rows=notes(search)
    if not rows:st.info('No saved notes yet.')
    for n in rows:
        with st.expander(('⭐ ' if n['fav'] else '')+f"{n['title']} — {n['subject']} — {n['created']}"):
            title2=st.text_input('Title',n['title'],key=f't{n["id"]}'); sub2=st.text_input('Subject',n['subject'],key=f's{n["id"]}'); body=st.text_area('Edit notes (Markdown)',n['content'],height=220,key=f'b{n["id"]}')
            a,b,d=st.columns(3)
            if a.button('Save edits',key=f'save{n["id"]}'):
                with conn() as c:c.execute('UPDATE notes SET title=?,subject=?,content=? WHERE id=?',(title2,sub2,body,n['id']))
                st.success('Saved.');st.rerun()
            if b.button('Toggle favourite',key=f'fav{n["id"]}'):
                with conn() as c:c.execute('UPDATE notes SET fav=1-fav WHERE id=?',(n['id'],))
                st.rerun()
            if d.button('Delete',key=f'del{n["id"]}'):
                with conn() as c:c.execute('DELETE FROM notes WHERE id=?',(n['id'],))
                st.rerun()
            st.download_button('Download TXT',body,file_name=f'notes-{n["id"]}.txt',key=f'txt{n["id"]}')
            st.download_button('Download PDF',pdf_bytes(title2,body),file_name=f'notes-{n["id"]}.pdf',mime='application/pdf',key=f'pdf{n["id"]}')
with tabs[4]:
    st.subheader('Quiz and practice tests'); rows=notes()
    if not rows:st.info('Create notes first.')
    else:
        labels={f"{n['title']} — {n['subject']} (#{n['id']})":n for n in rows}; label=st.selectbox('Choose saved note',list(labels)); typ=st.selectbox('Question type',['Mixed','MCQ','True or False','Fill in the Blanks','Short Answer','Important Exam Question']); count=st.slider('Number of questions',3,30,10)
        if st.button('Generate quiz',type='primary'):
            n=labels[label]; qs=makequiz(n['content'],count,typ)
            if qs:st.session_state['quiz']={'note':n,'questions':qs};st.session_state.pop('quiz_result',None)
            else:st.warning('Not enough factual content detected. Add fuller notes.')
        quiz=st.session_state.get('quiz')
        if quiz:
            st.markdown(f"### {quiz['note']['title']} · {len(quiz['questions'])} questions")
            with st.form('answers'):
                answers=[]
                for i,q in enumerate(quiz['questions']):
                    st.markdown(f"**Q{i+1}. {q['question']}**")
                    if q['options']:ans=st.radio('Choose',q['options'],key=f'q{i}',index=None)
                    else:ans=st.text_input('Your answer',key=f'q{i}')
                    answers.append(ans or '')
                submit=st.form_submit_button('Submit and grade',type='primary')
            if submit:
                details=[];score=0
                for i,q in enumerate(quiz['questions']):
                    ok=grade(answers[i],q['answer'],q['type']);score+=int(ok);details.append({'question':q['question'],'answer':answers[i],'expected':q['answer'],'correct':ok,'explanation':q['explanation']})
                total=len(details);pct=round(score*100/total,1)
                n=quiz['note']
                with conn() as c:c.execute('INSERT INTO tests(note_id,title,subject,score,total,pct,details,created) VALUES(?,?,?,?,?,?,?,?)',(n['id'],n['title'],n['subject'],score,total,pct,json.dumps(details),now()))
                st.session_state['quiz_result']={'score':score,'total':total,'pct':pct,'details':details};st.session_state.pop('quiz',None);st.rerun()
        result=st.session_state.get('quiz_result')
        if result:
            st.success(f"Score: {result['score']} / {result['total']} ({result['pct']}%)")
            for i,d in enumerate(result['details'],1):
                st.markdown(f"**{i}. {'✅' if d['correct'] else '❌'} {d['question']}**");st.write('Your answer:',d['answer'] or 'Not answered');st.write('Expected:',d['expected']);st.caption(d['explanation'])
            if st.button('Clear result'):st.session_state.pop('quiz_result',None);st.rerun()
with tabs[5]:
    st.subheader('History')
    with conn() as c:recs=[dict(x) for x in c.execute('SELECT * FROM recordings ORDER BY id DESC')];tests=[dict(x) for x in c.execute('SELECT * FROM tests ORDER BY id DESC')]
    st.markdown('#### Recordings')
    for r in recs:
        with st.expander(f"{r['title']} — {r['subject']} — {r['created']}"):st.text_area('Transcript',r['transcript'],height=120,key=f'h{r["id"]}')
    if not recs:st.caption('No recordings yet.')
    st.markdown('#### Test results')
    for t in tests:st.write(f"**{t['title']}** — {t['score']}/{t['total']} ({t['pct']}%) · {t['created']}")
    if not tests:st.caption('No tests completed yet.')
st.caption('Notes and quizzes are rule-based and grounded in the supplied lecture text. Short-answer grading is approximate. Audio transcription requires your own OpenAI API key. No login system is included.')
