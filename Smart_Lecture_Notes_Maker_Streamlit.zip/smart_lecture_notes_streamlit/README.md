# Smart Lecture Notes Maker — Streamlit Cloud version

## Deploy using your Samsung phone
1. Download and extract this ZIP.
2. Create a GitHub repository and upload the files in this folder. Keep `streamlit_app.py`, `requirements.txt` and `.streamlit/config.toml` at the repository root.
3. Open https://share.streamlit.io/ and sign in with GitHub.
4. Select **Create app**, choose your repository and branch, and set **Main file path** to `streamlit_app.py`.
5. Press **Deploy**.

## Enable speech-to-text
In Streamlit Cloud open **App settings → Secrets** and add:

```toml
OPENAI_API_KEY = "your-api-key"
```

Do not commit or share your API key. Audio recording/upload is available in supported Streamlit versions; transcription uses the OpenAI Audio Transcriptions API and needs this key. Without it, the app reports that transcription is not configured; it does not create fake text.

## Features
- Dashboard and usage counts
- Text-to-notes in Cornell, Outline, Mind Map and Chart formats
- Audio capture/upload and real API transcription
- Editable, searchable, favourite and deletable notes
- TXT and PDF export
- Quiz generation from saved notes, submission, score and explanations
- Recording and test history
- SQLite storage

## Limitations
- Notes and quizzes use rule-based processing, not an LLM.
- Short-answer grading is approximate keyword matching.
- No user accounts or private multi-user access.
- Streamlit Community Cloud local storage is not guaranteed permanent; SQLite data may be lost when the app is reset or redeployed. Keep backups or use a managed external database for long-term storage.

## Run locally
```bash
pip install -r requirements.txt
streamlit run streamlit_app.py
```
