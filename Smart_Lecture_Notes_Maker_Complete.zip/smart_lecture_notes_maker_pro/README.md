# Smart Lecture Notes Maker — Full project

A mobile-friendly Flask website with typed lecture notes, browser microphone recording, speech-to-text integration, a saved-notes library, and quiz generation.

## Included
- Responsive purple/violet UI with dashboard and navigation
- Text-based notes generated from the submitted lecture text
- Cornell, Outline, Mind Mapping and Chart formats
- Edit, save, search, favourite, delete, TXT and PDF export
- Browser microphone recording using `getUserMedia` + `MediaRecorder`
- Audio file upload and playback of saved recordings
- Real speech-to-text through the OpenAI Audio Transcriptions API
- Transcript editing and note generation from transcribed content
- Quiz generation from saved notes: MCQ, True/False, Fill in the Blanks, Short Answer and Important Exam prompts
- One-question-at-a-time quiz, previous/next, confirmation before submit, score and answer explanations
- SQLite database for notes, recordings and test results

## Honest feature boundaries
- **Real transcription requires an OpenAI API key.** Without `OPENAI_API_KEY`, the recorder still captures audio in the browser, but the server returns a clear configuration error and does not invent a transcript.
- The default transcription model is `gpt-4o-mini-transcribe`. Set `OPENAI_TRANSCRIBE_MODEL` to another transcription model available to your API account if needed.
- Note generation and quiz generation are local, rule-based text processing grounded in the student's notes. This is not an LLM and can miss context, formulas, or complex relationships.
- MCQ/blank/true-false questions are auto-marked. Short-answer and exam-style answers use keyword overlap, not AI semantic grading. Always review the feedback.
- Difficulty is currently a practice setting label; it does not yet change the algorithmic difficulty of generated questions.
- This demo has no user accounts or access control. Do not deploy publicly with private lecture audio or sensitive information without adding authentication, secure storage, HTTPS and a privacy policy.

## Run locally
Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`.

To enable real speech transcription, set your API key before starting the server:

```bash
# macOS/Linux
export OPENAI_API_KEY="your_api_key"
# Windows PowerShell
$env:OPENAI_API_KEY="your_api_key"
python app.py
```

Never put a real API key in frontend JavaScript or commit it to a public GitHub repository.

## Deploy from an Android phone
A simple phone-only route is GitHub + Render:
1. Download and extract the ZIP on your Samsung phone (My Files can extract ZIPs).
2. In Chrome, create a GitHub repository and upload the project files while preserving `templates/` and `static/` folders.
3. Open https://render.com/ and sign in with GitHub.
4. Create **New + → Web Service**, connect the repository.
5. Set **Build Command** to `pip install -r requirements.txt`.
6. Set **Start Command** to `gunicorn app:app`.
7. Add an environment variable `OPENAI_API_KEY` only if you have an API key and want real transcription. Keep it secret.
8. Deploy and open the HTTPS `onrender.com` URL. Microphone access generally requires HTTPS (or localhost).

Render free instances may sleep, and local files/SQLite/uploads on ephemeral storage may be lost on redeploy or instance replacement. For persistent production use, attach a persistent disk or use managed database/object storage. Do not assume a free deployment is permanent.

## Sample test
Use `sample_lecture.txt`. Copy the lecture into the Notes Generator, set:
- Title: Introduction to Data Structures
- Subject: Programming Fundamentals
- Method: Cornell Method

Generate notes, open Test Yourself, choose the saved note, and generate a quiz.

## Project structure
- `app.py` — Flask backend, SQLite schema, note/quiz logic, transcription endpoint
- `templates/index.html` — website structure
- `static/style.css` — responsive design
- `static/app.js` — navigation, recorder, API calls and quiz interactions
- `requirements.txt` — dependencies
- `sample_lecture.txt` — sample lecture content
- `smart_notes.db` — created automatically at first run
- `uploads/` — created automatically for audio files
